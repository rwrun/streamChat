//error nil

import Foundation

struct UserInfo{
    let email: String
    let password: String
    var name: String? = nil
}
