//error nil

import MessageKit

struct Sender: SenderType{
    var senderId: String
    var displayName: String
}
