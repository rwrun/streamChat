//error nil

import Foundation

extension NSNotification.Name{
    static let windowManager = NSNotification.Name("windowManager")
}
